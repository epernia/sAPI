MicroPython documentation and references
========================================

.. toctree::

    library/index.rst
    license.rst
    unix_contents.rst

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
