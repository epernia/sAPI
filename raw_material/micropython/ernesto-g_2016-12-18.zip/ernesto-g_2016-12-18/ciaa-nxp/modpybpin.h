uint32_t getPinNumber(void* pObj);

