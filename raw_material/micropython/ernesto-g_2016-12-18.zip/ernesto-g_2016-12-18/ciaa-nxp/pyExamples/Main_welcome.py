print("Welcome to Micropython on EDU-CIAA-NXP")
