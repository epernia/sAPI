void boot(void);

