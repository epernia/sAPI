sAPI v0.5.0

Copyright (c) 2015-2017, Eric Pernia
All rights reserved.

