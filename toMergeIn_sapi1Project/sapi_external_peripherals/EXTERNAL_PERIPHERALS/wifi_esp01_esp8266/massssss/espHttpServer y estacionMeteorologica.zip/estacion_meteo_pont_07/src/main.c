/* Copyright 2017, Agustin Bassi.
 * All rights reserved.
 *
 * This file is part sAPI library for microcontrollers.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/*
 * Date: 2017-11-24
 */

/*==================[inlcusiones]============================================*/

#include "main.h"
#include "api.h"
#include "sapi.h"
#include "cooperativeOs_isr.h"       // <= dispatcher and task management header
#include "cooperativeOs_scheduler.h" // <= scheduler and system initialization header

/*==================[macros and definitions]=================================*/

// Periodicidad de las tareas
#define PERIODICIDAD_LEER_SENSORES       2000
#define PERIODICIDAD_ESCRIBIR_SD         5000
#define PERIODICIDAD_ESCRIBIR_UART       2500
#define PERIODICIDAD_ESCRIBIR_BLUETOOTH  2500
#define PERIODICIDAD_MOSTRAR_TEMPERATURA 2500
#define PERIODICIDAD_ESCRIBIR_LCD        PERIODICIDAD_LEER_SENSORES
#define PERIODICIDAD_ESCRIBIR_WIFI       10 // @Actividad_6

// configuracion de la aplicacion
#define _SYS_CFG_DATALOG_FILENAME 		"datalog.txt"
// configuraciones iniciales de los sensores
#define _SYS_CFG_SENSOR_ENABLE_TEMP		(1)
#define _SYS_CFG_SENSOR_ENABLE_HUM		(1)
#define _SYS_CFG_SENSOR_ENABLE_WIND		(1)

/*==================[definiciones de datos internos]=========================*/

// Flags de habilitacion de los sensores
bool_t sysCfgSensorEnableTemp 	= _SYS_CFG_SENSOR_ENABLE_TEMP;
bool_t sysCfgSensorEnableHum 	= _SYS_CFG_SENSOR_ENABLE_HUM;
bool_t sysCfgSensorEnableWind 	= _SYS_CFG_SENSOR_ENABLE_WIND;
// Valores de la lectura de los sensores
uint16_t sensorTempValue = 0;
uint16_t sensorHumValue  = 0;
uint16_t sensorWindValue = 0;
// Array donde se formatea la informacion
uint8_t bufferDataLog[128];

/*==================[definiciones de datos externos]=========================*/

/*==================[declaraciones de funciones internas]====================*/

uint8_t EjecutarBootloader             (void);
bool_t 	TareaLeerSensores              ( void* ptr );
bool_t 	TareaEscribirSensoresSd        ( void* ptr );
bool_t 	TareaEscribirSensoresUart      ( void* ptr );
bool_t 	TareaEscribirSensoresBluetooth ( void* ptr );
bool_t 	TareaMostrarTemperaturaEnLed   ( void* ptr );
bool_t   TareaEscribirSensoresLcd       ( void* ptr );
bool_t   TareaEscribirSensoresWifi      ( void* ptr ); // @Actividad_6

/*==================[declaraciones de funciones externas]====================*/

/*==================[funcion principal]======================================*/

int main( void ){
	//Inicializar el hardware, perifericos, puertos, clock, etc.
	apiConfigHardware();
	//Carga las configuraciones iniciales de la estacion metereologica
	EjecutarBootloader();

	//FUNCION que inicializa el planificador de tareas
	schedulerInit();
	//Cargar las tareas del sistema operativo con sus periodicidades
	schedulerAddTask( TareaLeerSensores,               0, PERIODICIDAD_LEER_SENSORES );
	schedulerAddTask( TareaEscribirSensoresSd,        10, PERIODICIDAD_ESCRIBIR_SD );
	schedulerAddTask( TareaEscribirSensoresUart,      20, PERIODICIDAD_ESCRIBIR_UART );
	schedulerAddTask( TareaEscribirSensoresBluetooth, 30, PERIODICIDAD_ESCRIBIR_BLUETOOTH );
	schedulerAddTask( TareaMostrarTemperaturaEnLed,   50, PERIODICIDAD_MOSTRAR_TEMPERATURA );
	schedulerAddTask( TareaEscribirSensoresLcd,       50, PERIODICIDAD_ESCRIBIR_LCD );

	//Iniciar el planificador de tareas
	schedulerStart( 1 );
	//Lazo infinito

	while(TRUE) {
		//Ejecutar tareas
	   TareaEscribirSensoresWifi(0); // @Actividad_6
		schedulerDispatchTasks();
	}
	return 0;
}

/*==================[definiciones de funciones internas]=====================*/

//Esta funcion seria analoga a ejecutar un Bootloader
//(un paso previo a iniciar el sistema, como ocurre en una PC).
uint8_t EjecutarBootloader(void) {
	apiEnviarMensajeBienvenida();
	apiMostrarSensoresEnLeds(sysCfgSensorEnableTemp, sysCfgSensorEnableHum, sysCfgSensorEnableWind);
	apiConfigurarSensores(&sysCfgSensorEnableTemp, &sysCfgSensorEnableHum, &sysCfgSensorEnableWind);
	apiHabilitarSensores(sysCfgSensorEnableTemp, sysCfgSensorEnableHum, sysCfgSensorEnableWind);
	return 0;
}

bool_t 	TareaLeerSensores ( void* ptr ){
	apiReadSensor(&sensorTempValue, &sensorHumValue, &sensorWindValue);
	apiProcessInformation(sensorTempValue, sensorHumValue, sensorWindValue,	bufferDataLog);
	return 0;
}

bool_t 	TareaEscribirSensoresSd ( void* ptr ){
	//	apiWriteSD(_SYS_CFG_DATALOG_FILENAME, bufferDataLog);
	return 0;
}

bool_t 	TareaEscribirSensoresUart ( void* ptr ){
	uartWriteString(UART_USB, (char *)bufferDataLog);
	uartWriteString(UART_USB, "\n\r");
	return 0;
}

bool_t 	TareaEscribirSensoresBluetooth ( void* ptr ){
	uartWriteString(UART_GPIO, (char *)bufferDataLog);
	return 0;
}

bool_t 	TareaMostrarTemperaturaEnLed ( void* ptr ){
	apiMostrarTemperaturaEnLed(sensorTempValue);
	return 0;
}

bool_t 	TareaEscribirSensoresLcd( void* ptr ){

	char tempUmmVie[] = "0000  0000  0000";

	apiProcessInformationForLCD( sensorTempValue,
		    					 sensorHumValue,
								 sensorWindValue,
								 tempUmmVie );
	apiEscribirSensoresLcd( tempUmmVie );
	return 0;
}


bool_t   TareaEscribirSensoresWifi( void* ptr ){ // @Actividad_6
   apiEscribirSensoresWiFi( sensorTempValue, sensorHumValue, sensorWindValue );
   return 0;
}

/*==================[definiciones de funciones externas]=====================*/

/*==================[fin del archivo]========================================*/

