/* Copyright 2017, Agustin Bassi.
 * All rights reserved.
 *
 * This file is part sAPI library for microcontrollers.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/*
 * Date: 2017-11-24
 */

/*==================[inlcusiones]============================================*/

#include "api.h"

/*==================[definiciones y macros]==================================*/

// @Actividad_6
// Se deben definir los datos del nombre de la red y la contrasenia.
#define WIFI_NAME        "casaEric" // "WiFi-Arnet-ucx1"
#define WIFI_PASS        "fide1634" // "NWVPHW7KWC"
// El maximo tiempo que se espera una respuesta del modulo ESP8266
#define WIFI_MAX_DELAY 60000

/*==================[definiciones de datos internos]=========================*/

static bool_t enableTemp = 1;
static bool_t enableHum  = 1;
static bool_t enableWind = 1;

// @Actividad_6
bool_t error;
uint8_t counter = 0;
delay_t wifiDelay;

static const char tempChar[8] = { //Temperatura - Termometro
	0b01110,
	0b01010,
	0b01010,
	0b01110,
	0b01110,
	0b11111,
	0b11111,
	0b01110
};

static const char humChar[8] = { // Humedad - Gota
	0b00100,
	0b00100,
	0b01110,
	0b10111,
	0b10111,
	0b10011,
	0b01110,
	0b00000
};

static const char vieChar[8] = { // Viento
	0b01000,
	0b00100,
	0b10010,
	0b01001,
	0b00100,
	0b10010,
	0b01000,
	0b00100
};

const char HttpWebPageHeader[] = "<head><title>Estacion Meteorologica</title><meta http-equiv=\"refresh\" content=\"15\"></head><p>&nbsp;</p><p>&nbsp;</p><p style=\"text-align: center;\">&nbsp;<img style=\"text-align: center;\" src=\"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRwMNEJYykiWtmU1EE5j8H6BPYwO6ewxdVzeJoV7_tnEpDg2Z199A\" alt=\"logo\" width=\"200\" height=\"150\" /></p><div><h1 style=\"text-align: center;\">Estacion Meteorologica <br />con Sistema Operativo de Tiempo Real<br /><br /></h1></div><div style=\"text-align: center;\">Actualizacion automatica de la pagina web cada 15 segundos</div><div style=\"text-align: center;\">&nbsp;</div><div style=\"text-align: center;\">LED1, LED2 y LED3 indican el estado de los sensores de Temperatura, Humedad y Viento <br /><br /></div><div style=\"text-align: center;\">El LED RGB indica la temperatura sensada (Azul = FRIO, Verde = NORMAL, Rojo = CALOR)<br /><br /><br />&nbsp;</div><div style=\"text-align: center;\">&nbsp;</div><div><table class=\"sensorTable\" style=\"height: 53px; width: 509px; margin-left: auto; margin-right: auto;\"><tbody><tr style=\"height: 10px;\"><td style=\"width: 158px; height: 10px; text-align: center;\"><p><strong> Temperatura</strong></p><p>&nbsp;</p><p>&nbsp;</p></td><td style=\"width: 164.5px; height: 10px; text-align: center;\"><p><strong> Humedad</strong></p><p>&nbsp;</p><p>&nbsp;</p></td><td style=\"width: 164.5px; height: 10px; text-align: center;\"><p><strong> Viento</strong></p><p>&nbsp;</p><p>&nbsp;</p></td></tr><tr style=\"height: 35px;\">";

const char HttpWebPageEnd[] ="</tr></tbody></table></div><div><p><br />&nbsp;</p></div><div><hr /></div><div><p style=\"text-align: center;\">Copyright Su Nombre y Apellido - All rights reserverd</p><p style=\"text-align: center;\">Cursos INET 2017 Sistemas Embebidos - Nivel 3</p><p style=\"text-align: center;\"><a href=\"http://www.proyecto-ciaa.com.ar\">www.proyecto-ciaa.com.ar</a></p><p style=\"text-align: center;\">&nbsp;</p></div>";

char HttpWebPageBody[200];

/*==================[definiciones de datos externos]=========================*/

/*==================[declaraciones de funciones internas]====================*/

static void    FormatInformationArray      (uint16_t valor, uint8_t * destiny, uint8_t pos);
static uint8_t apiConfig_SensorTemp_Enable (bool_t flagEnable);
static uint8_t apiConfig_SensorHum_Enable  (bool_t flagEnable);
static uint8_t apiConfig_SensorWind_Enable (bool_t flagEnable);
static void apiConfigLCD(void);

/*==================[declaraciones de funciones externas]====================*/

/*==================[definiciones de funciones internas]=====================*/

static void    FormatInformationArray(uint16_t valor, uint8_t * destiny, uint8_t pos){
	destiny[pos] = valor/1000 		+ '0';
	pos++;
	destiny[pos] = (valor%1000)/100 + '0';
	pos++;
	destiny[pos] = (valor%100)/10 	+ '0';
	pos++;
	destiny[pos] = (valor%10) 		+ '0';
}

static uint8_t apiConfig_SensorTemp_Enable (bool_t flagEnable) {
	enableTemp = flagEnable;
	return _API_STATE_OK;
}

static uint8_t apiConfig_SensorHum_Enable(bool_t flagEnable) {
	enableHum = flagEnable;
	return _API_STATE_OK;
}

static uint8_t apiConfig_SensorWind_Enable(bool_t flagEnable) {
	enableWind = flagEnable;
	return _API_STATE_OK;
}

static void apiConfigLCD(void){
	lcdInit( 16, 2, 5, 8 );

	// Cargar el caracter a CGRAM
	// El primer parámetro es el código del caracter (0 a 7).
	// El segundo es el puntero donde se guarda el bitmap (el array declarado anteriormente)

	lcdCreateChar( 0, tempChar );
	lcdCreateChar( 1, humChar );
	lcdCreateChar( 2, vieChar );

	delay(1000);

	lcdClear(); // Borrar la pantalla
	lcdGoToXY( 1, 1 ); // Poner cursor en 1, 1
	lcdSendStringRaw( "Bienvenido!!!   " );
	lcdGoToXY( 1, 2 ); // Poner cursor en 1, 1
	lcdSendStringRaw( "Estacion Meteo  " );
	delay(2000);
	lcdClear(); // Borrar la pantalla
	lcdGoToXY( 1, 1 ); // Poner cursor en 1, 1
	lcdSendStringRaw( "Cursos INET     " );
	delay(2000);

	lcdClear(); // Borrar la pantalla
	lcdGoToXY( 1, 1 ); // Poner cursor en 1, 1
	lcdSendStringRaw( "Temp" );
	lcdData(0);
	lcdSendStringRaw( " Hum" );
	lcdData(1);
	lcdSendStringRaw( "  Vie" );
	lcdData(2);
	// lcdSendStringRaw( "Temp  Hum   Vie " );
}

static void apiConfigServer(void){ // @Actividad_6

   // Envia un mensaje de bienvenida.
   stdioPrintf(UART_USB, "\n\rBienvenido al servidor HTTP Esp8266 con EDU CIAA");
   stdioPrintf(UART_USB, "\n\rLa configuracion puede tardar hasta 1 minuto.");

   error = FALSE;
   // Configura un delay para salir de la configuracion en caso de error.
   delayConfig(&wifiDelay, WIFI_MAX_DELAY);

   // Mientras no termine la configuracion o mientras no pase el tiempo maximo, ejecuta la configuracion.
   // A la configuracion se le pasa nombre y contrasenia de RED
   // En caso de querer ver los mensajes que se envian/reciben desde el modulo
   // se debe tambien mandar la UART por donde van a salir esos datos. Ejemplo:
   // esp8266ConfigHttpServer(WIFI_NAME, WIFI_PASS, UART_USB, 115200);
   while (!esp8266ConfigHttpServer(WIFI_NAME, WIFI_PASS, 0, 0) && !error){
      if (delayRead(&wifiDelay)){
         error = TRUE;
      }
   }

   // Avisa al usuario como salio la configuracion
   if (!error){
      stdioPrintf(UART_USB, "\n\rServidor HTTP configurado. IP: %s", esp8266GetIpAddress());
      // Enciende LEDG indicando que el modulo esta configurado.
      gpioWrite(LEDG, TRUE);
   } else {
      stdioPrintf(UART_USB, "\n\rError al configurar servidor HTTP");
      // Enciende LEDR indicando que el modulo esta en error.
      gpioWrite(LEDR, TRUE);
   }
}


/*==================[declaraciones de funciones externas]====================*/

void    apiConfigHardware (void){
	boardConfig();
	uartConfig(UART_USB, 115200);
	adcConfig(ADC_ENABLE);
	spiConfig(SPI0);
   uartConfig(UART_GPIO, 9600); // UART Bluetooth // @Actividad_6
	//	tickConfig(10, diskTickHook);
	apiConfigLCD();
	apiConfigServer(); // @Actividad_6
   delay(500);
}

void    apiEnviarMensajeBienvenida(void){
	uartWriteString(UART_USB, "\r\n-------------------------------------\n");
	uartWriteString(UART_USB, "  Bienvenido!!! Estacion Meteo INET  \n");
	uartWriteString(UART_USB, "-----------------------------\n");
	uartWriteString(UART_USB, "Seleccione el sensor\n");
	uartWriteString(UART_USB, "1 - Temperatura\n");
	uartWriteString(UART_USB, "2 - Humedad\n");
	uartWriteString(UART_USB, "3 - Viento\n");
	uartWriteString(UART_USB, "0 - Salir\n");

	uartWriteString(UART_232, "Conectado a Estacion Meteorologica INET");
}

void    apiConfigurarSensores(bool_t * sysCfgSensorEnableTemp, bool_t * sysCfgSensorEnableHum, bool_t * sysCfgSensorEnableWind ){
	uint32_t todosLosValoresCargados = FALSE;
	uint8_t dataUart;
	while(todosLosValoresCargados == FALSE){
		// Recibe tanto comandos por la UART USB o por Bluetooth.
		if(uartReadByte(UART_USB, &dataUart) || uartReadByte(UART_232, &dataUart)){
			if(dataUart == '0' || dataUart == '1' || dataUart == '2' || dataUart == '3'){
				if(dataUart == '0'){
					todosLosValoresCargados = TRUE;
				} else if(dataUart == '1'){
					*sysCfgSensorEnableTemp 	= !*sysCfgSensorEnableTemp;
					if(*sysCfgSensorEnableTemp){
						uartWriteString(UART_USB, "Temperatura: ON\n");
						uartWriteString(UART_232, "Temperatura: ON");
					} else {
						uartWriteString(UART_USB, "Temperatura: OFF\n");
						uartWriteString(UART_232, "Temperatura: OFF");
					}
				} else if(dataUart == '2'){
					*sysCfgSensorEnableHum 	= !*sysCfgSensorEnableHum;
					if(*sysCfgSensorEnableHum){
						uartWriteString(UART_USB, "Humedad: ON\n");
						uartWriteString(UART_232, "Humedad: ON");
					} else {
						uartWriteString(UART_USB, "Humedad: OFF\n");
						uartWriteString(UART_232, "Humedad: OFF");
					}
				} else if(dataUart == '3'){
					*sysCfgSensorEnableWind 	= !*sysCfgSensorEnableWind;
					if(*sysCfgSensorEnableWind){
						uartWriteString(UART_USB, "Viento: ON\n");
						uartWriteString(UART_232, "Viento: ON");
					} else {
						uartWriteString(UART_USB, "Viento: OFF\n");
						uartWriteString(UART_232, "Viento: OFF");
					}
				}
				apiMostrarSensoresEnLeds(*sysCfgSensorEnableTemp, *sysCfgSensorEnableHum, *sysCfgSensorEnableWind);
			} else {
				uartWriteString(UART_USB, "Comando invalido!\n");
				uartWriteString(UART_232, "Comando invalido!");
			}
		}
	}
	uartWriteString(UART_USB, "Configuracion terminada\n");
	uartWriteString(UART_232, "Configuracion terminada\n");
}

void    apiHabilitarSensores(bool_t sysCfgSensorEnableTemp, bool_t sysCfgSensorEnableHum, bool_t sysCfgSensorEnableWind ){
	apiConfig_SensorTemp_Enable(sysCfgSensorEnableTemp);
	apiConfig_SensorHum_Enable(sysCfgSensorEnableHum);
	apiConfig_SensorWind_Enable(sysCfgSensorEnableWind);
}

void    apiMostrarSensoresEnLeds (bool_t sysCfgSensorEnableTemp, bool_t sysCfgSensorEnableHum, bool_t sysCfgSensorEnableWind ){
	gpioWrite(LED1, sysCfgSensorEnableTemp);
	gpioWrite(LED2, sysCfgSensorEnableHum);
	gpioWrite(LED3, sysCfgSensorEnableWind);
}

void    apiMostrarTemperaturaEnLed (uint16_t dataTemp){
	if (dataTemp < 300){
		gpioWrite(LEDR, OFF);
		gpioWrite(LEDG, OFF);
		gpioWrite(LEDB, ON);
	} else if (dataTemp < 600){
		gpioWrite(LEDR, OFF);
		gpioWrite(LEDG, ON);
		gpioWrite(LEDB, OFF);
	} else {
		gpioWrite(LEDR, ON);
		gpioWrite(LEDG, OFF);
		gpioWrite(LEDB, OFF);
	}
}

uint8_t apiReadTemperatureHumdity(uint16_t * dataTemp, uint16_t * dataHum) {
	uint16_t adcValue1, adcValue2;

	adcValue1 = adcRead(CH1); // temp
	(*dataTemp) = adcValue1;

	adcValue2 = adcRead(CH2); // hum
	(*dataHum) = adcValue2;

	return _API_STATE_OK;
}

uint8_t apiReadWind(uint16_t * dataWind) {
	uint16_t adcValue3 = 0;

	adcValue3 = adcRead(CH3); // viento
	(*dataWind) = adcValue3;

	return _API_STATE_OK;
}

uint8_t apiReadSensor(uint16_t * dataTemp, uint16_t * dataHum, uint16_t * dataWind) {

	apiReadTemperatureHumdity(dataTemp, dataHum);

	apiReadWind(dataWind);

	return _API_STATE_OK;
}

uint8_t apiProcessInformation(uint16_t dataTemp, uint16_t dataHum, uint16_t dataWind, uint8_t * destiny) {
uint8_t spaces;
uint8_t pos = 0;
	/*
	 * Recibir 3 datos enteros X, Y, Z
	 * posiciones	= 0123 4 5678 9 0123 4 5  6  7
	 * formato 		= XXXX ; YYYY ; ZZZZ ; \r \n \0
	 * formato 		= XXXX ;  ;  ; \r \n \0
	 */
	if(enableTemp) {
		FormatInformationArray(dataTemp, destiny, pos);
		pos += 4;
	}
	for (spaces = 0; spaces < 15; spaces++){
		destiny[pos] = ' ';
		pos++;
	}
	if(enableHum) {
		FormatInformationArray(dataHum, destiny, pos);
		pos += 4;
	}
	for (spaces = 0; spaces < 15; spaces++){
		destiny[pos] = ' ';
		pos++;
	}
	if(enableWind) {
		FormatInformationArray(dataWind, destiny, pos);
		pos += 4;
	}
	destiny[pos] = '\r';
	pos++;
	destiny[pos] = '\n';
	pos++;
	destiny[pos] = '\0';
	pos++;

	return _API_STATE_OK;
}

uint8_t apiWriteSD(uint8_t * filename, uint8_t * stringData) {

	if(apiSD_Init() == _API_STATE_ERROR) {
		// error
	} else {
		if(apiSD_Write((char*)filename, (char*)stringData) == _API_STATE_ERROR) {
			// error
			gpioWrite( LEDR, ON );
		} else {
			// ok
			gpioWrite( LEDG, ON );
		}
	}

	return _API_STATE_OK;
}

void apiEscribirSensoresLcd( char * bufferDataLog ){
	lcdGoToXY( 1, 2 );  // Poner cursor en 1, 2
	lcdSendStringRaw( bufferDataLog );
}

void apiProcessInformationForLCD( uint16_t dataTemp,
	                              uint16_t dataHum,
							      uint16_t dataWind,
						          char* destiny ){
	FormatInformationArray( dataTemp, (uint8_t*)destiny, 0 );
	FormatInformationArray( dataHum, (uint8_t*)destiny, 6 );
	FormatInformationArray( dataWind, (uint8_t*)destiny, 13 );
}


//Flag que mantiene el valor entre llamadas para chequear si hay peticiones HTTP
void apiEscribirSensoresWiFi( uint16_t sensorTempValue,
                              uint16_t sensorHumValue,
                              uint16_t sensorWindValue ){ // @Actividad_6
   /*
   static bool_t request = FALSE;

   // Si no hay ninguna peticion pendiente...
   if (request == FALSE){
      // Si llega una peticion activa el flag request para responder la peticion
      if (esp8266ReadHttpServer()){
         //Formatea el arreglo HttpWebPageBody con datos HTML y los valores de los sensores
         stdioSprintf(HttpWebPageBody,
         "<td style=\"text-align: center;\"><h2>%d</h2></td>"
         "<td style=\"text-align: center;\"><h2>%d</h2></td>"
         "<td style=\"text-align: center;\"><h2>%d</h2></td>",
         sensorTempValue,
         sensorHumValue,
         sensorWindValue);
         request = TRUE;
      }
   }

   // Si hay una peticion pendiente ...
   else {
      // Envia los datos de la pagina web actualizados al cliente.
      // Si el envio termina se pone a request en FALSE para terminar la transaccion.
      if (esp8266WriteHttpServer(HttpWebPageHeader, HttpWebPageBody, HttpWebPageEnd)){
         request = FALSE;
      }
   }
   */

   // Si llego una peticion al servidor http
   if (esp8266ReadHttpServer()){

      // Los datos a enviar a la web deben estar en formato HTML.

      stdioSprintf(HttpWebPageBody,
            "<td style=\"text-align: center; color:#00FF33; \"><h2>%d</h2></td>"
            "<td style=\"text-align: center;\"><h2>%d</h2></td>"
            "<td style=\"text-align: center;\"><h2>%d</h2></td>",
            sensorTempValue,
            sensorHumValue,
            sensorWindValue);

      error = FALSE;
      // Configura un delay para salir de la configuracion en caso de error.
      delayConfig(&wifiDelay, WIFI_MAX_DELAY);

      // Mientras no termine el envio o mientras no pase el tiempo maximo, ejecuta el envio.
      while (!esp8266WriteHttpServer(HttpWebPageHeader, HttpWebPageBody, HttpWebPageEnd) && !error){
         if (delayRead(&wifiDelay)){
            error = TRUE;
         }
      }

      // Avisa al usuario como fue el envio
      if (!error){
         stdioPrintf(UART_USB, "\n\rPeticion respondida al cliente HTTP %d.", esp8266GetConnectionId());
         gpioToggle(LEDG);
      } else {
         stdioPrintf(UART_USB, "\n\rPeticion respondida al cliente HTTP %d.", esp8266GetConnectionId());
         gpioToggle(LEDR);
      }

      counter++;
   }
}

/*==================[fin del archivo]========================================*/

