/* Copyright 2017, Pablo Gomez - Agustin Bassi.
 * Copyright 2016, Marcelo.
 * All rights reserved.
 *
 * This file is part sAPI library for microcontrollers.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 */

/* Date: 2017-14-11 */

/*==================[inclusions]=============================================*/

#include "../../esp8266HttpServer_estacionMeteo_BareMetal/inc/sapi_esp8266.h"
#include "sapi.h"

/*==================[macros and definitions]=================================*/

// Se deben definir los datos del nombre de la red y la contrasenia.
#define WIFI_NAME        "casaEric" // "WiFi-Arnet-ucx1"
#define WIFI_PASS        "fide1634" // "NWVPHW7KWC"
// El maximo tiempo que se espera una respuesta del modulo ESP8266
#define WIFI_MAX_DELAY 60000

#define  BEGIN_USER_LINE "<h3 style=\"text-align: center;\"><strong>"
#define  END_USER_LINE   "</strong></h3>"

/*==================[internal functions declaration]=========================*/

/*==================[internal data definition]===============================*/

const char HttpWebPageHeader [] = "<head><title>Estacion Meteorologica</title><meta http-equiv=\"refresh\" content=\"15\"></head><p>&nbsp;</p><p>&nbsp;</p><p style=\"text-align: center;\">&nbsp;<img style=\"text-align: center;\" src=\"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRwMNEJYykiWtmU1EE5j8H6BPYwO6ewxdVzeJoV7_tnEpDg2Z199A\" alt=\"logo\" width=\"200\" height=\"150\" /></p><div><h1 style=\"text-align: center;\">Estacion Meteorologica <br />con Sistema Operativo de Tiempo Real<br /><br /></h1></div><div style=\"text-align: center;\">Actualizacion automatica de la pagina web cada 15 segundos</div><div style=\"text-align: center;\">&nbsp;</div><div style=\"text-align: center;\">LED1, LED2 y LED3 indican el estado de los sensores de Temperatura, Humedad y Viento <br /><br /></div><div style=\"text-align: center;\">El LED RGB indica la temperatura sensada (Azul = FRIO, Verde = NORMAL, Rojo = CALOR)<br /><br /><br />&nbsp;</div><div style=\"text-align: center;\">&nbsp;</div><div><table class=\"sensorTable\" style=\"height: 53px; width: 509px; margin-left: auto; margin-right: auto;\"><tbody><tr style=\"height: 10px;\"><td style=\"width: 158px; height: 10px; text-align: center;\"><p><strong> Temperatura</strong></p><p>&nbsp;</p><p>&nbsp;</p></td><td style=\"width: 164.5px; height: 10px; text-align: center;\"><p><strong> Humedad</strong></p><p>&nbsp;</p><p>&nbsp;</p></td><td style=\"width: 164.5px; height: 10px; text-align: center;\"><p><strong> Viento</strong></p><p>&nbsp;</p><p>&nbsp;</p></td></tr><tr style=\"height: 35px;\">";

const char HttpWebPageEnd [] ="</tr></tbody></table></div><div><p><br />&nbsp;</p></div><div><hr /></div><div><p style=\"text-align: center;\">Copyright Su Nombre y Apellido - All rights reserverd</p><p style=\"text-align: center;\">Cursos INET 2017 Sistemas Embebidos - Nivel 3</p><p style=\"text-align: center;\"><a href=\"http://www.proyecto-ciaa.com.ar\">www.proyecto-ciaa.com.ar</a></p><p style=\"text-align: center;\">&nbsp;</p></div>";

char HttpWebPageBody [200];

/*==================[external data definition]===============================*/

/*==================[internal functions definition]==========================*/

/*==================[external functions definition]==========================*/

/* FUNCION PRINCIPAL, PUNTO DE ENTRADA AL PROGRAMA LUEGO DE RESET. */
int main(void){
	bool_t error;
	uint8_t counter = 0;
	delay_t wifiDelay;
	uint16_t sensorTempValue = 2, sensorHumValue = 4, sensorWindValue = 6;

	// Inicializar la placa
	boardConfig ();
	// Configura la UART USB a 115200 baudios
	uartConfig (UART_USB, 115200);
	adcConfig(ADC_ENABLE);
	// Envia un mensaje de bienvenida.
	stdioPrintf(UART_USB, "\n\rBienvenido al servidor HTTP Esp8266 con EDU CIAA");
	stdioPrintf(UART_USB, "\n\rLa configuracion puede tardar hasta 1 minuto.");

	error = FALSE;
	// Configura un delay para salir de la configuracion en caso de error.
	delayConfig(&wifiDelay, WIFI_MAX_DELAY);

	// Mientras no termine la configuracion o mientras no pase el tiempo maximo, ejecuta la configuracion.
	// A la configuracion se le pasa nombre y contrasenia de RED
	// En caso de querer ver los mensajes que se envian/reciben desde el modulo
	// se debe tambien mandar la UART por donde van a salir esos datos. Ejemplo:
	// esp8266ConfigHttpServer(WIFI_NAME, WIFI_PASS, UART_USB, 115200);
	while (!esp8266ConfigHttpServer(WIFI_NAME, WIFI_PASS, 0, 0) && !error){
		if (delayRead(&wifiDelay)){
			error = TRUE;
		}
	}

	// Avisa al usuario como salio la configuracion
	if (!error){
		stdioPrintf(UART_USB, "\n\rServidor HTTP configurado. IP: %s", esp8266GetIpAddress());
		// Enciende LEDG indicando que el modulo esta configurado.
		gpioWrite(LEDG, TRUE);
	} else {
		stdioPrintf(UART_USB, "\n\rError al configurar servidor HTTP");
		// Enciende LEDR indicando que el modulo esta en error.
		gpioWrite(LEDR, TRUE);
	}

	/* ------------- REPETIR POR SIEMPRE ------------- */
	while(1) {
		// Si llego una peticion al servidor http
		if (esp8266ReadHttpServer()){

			// Los datos a enviar a la web deben estar en formato HTML.

			stdioSprintf(HttpWebPageBody,
					"<td style=\"text-align: center;\"><h2>%d</h2></td>"
					"<td style=\"text-align: center;\"><h2>%d</h2></td>"
					"<td style=\"text-align: center;\"><h2>%d</h2></td>",
					sensorTempValue,
					sensorHumValue,
					sensorWindValue);

			sensorTempValue += 2;
			sensorHumValue += 4;
			sensorWindValue += 6;

			error = FALSE;
			// Configura un delay para salir de la configuracion en caso de error.
			delayConfig(&wifiDelay, WIFI_MAX_DELAY);

			// Mientras no termine el envio o mientras no pase el tiempo maximo, ejecuta el envio.
			while (!esp8266WriteHttpServer(HttpWebPageHeader, HttpWebPageBody, HttpWebPageEnd) && !error){
				if (delayRead(&wifiDelay)){
					error = TRUE;
				}
			}

			// Avisa al usuario como fue el envio
			if (!error){
				stdioPrintf(UART_USB, "\n\rPeticion respondida al cliente HTTP %d.", esp8266GetConnectionId());
				gpioToggle(LEDG);
			} else {
				stdioPrintf(UART_USB, "\n\rPeticion respondida al cliente HTTP %d.", esp8266GetConnectionId());
				gpioToggle(LEDR);
			}

			counter++;
		}
	}

	/* NO DEBE LLEGAR NUNCA AQUI, debido a que a este programa no es llamado
      por ningun S.O. */
	return 0 ;
}



/*==================[end of file]============================================*/
