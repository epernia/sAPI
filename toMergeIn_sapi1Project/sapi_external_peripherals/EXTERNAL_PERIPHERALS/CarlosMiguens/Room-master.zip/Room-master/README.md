# Room controller implemented on FreeOSEK and EDU-CIAA board

Implemented for a restroom

Sensors:

* Humidity, move, key1, key2

Actions:

* Lights ON/OFF, Fan ON/OFF
