/*
 * actions.h
 *
 *  Created on: Aug 1, 2017
 *      Author: Carlos Miguens
 */

#ifndef APPLICATION_ROOM_SRC_ACTIONS_H_
#define APPLICATION_ROOM_SRC_ACTIONS_H_

void actionsTask(void);
void initActions(void);

#endif
